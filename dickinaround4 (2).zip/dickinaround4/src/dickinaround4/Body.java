package dickinaround4;


import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.ArrayList;



public class Body{

	public int x, y;
	public static int width = 5;
	public static int height = 5;
	public static ArrayList<Rectangle> body;
	public Enemy enemy;
	public static int length = 10;

	
	public Body(Enemy enemy){
		this.enemy = enemy;
		body = new ArrayList<Rectangle>();
		body.add(new Rectangle(300, 150, width, height));
		for(int x = 0; x < length; x++){
			addSegment();
		}

	}
	
	public void addSegment(){
		body.add(new Rectangle(body.get(body.size() - 1).x - width, body.get(body.size() - 1).y , width, height));
		
		
		
	}
	
	public void repaint(Graphics g){
		g.setColor(Color.RED);
		for(Rectangle segment : body){
			g.fillRect(segment.x, segment.y, width, height);
		}
		

	}
	
	public void update(){
		for(int i = body.size() - 1; i > 0; i--){
			body.get(i).x = body.get(i - 1).x;
			body.get(i).y = body.get(i - 1).y;
		}
		checkCollision();
	}
	
	
	public void checkCollision(){
		if(body.get(0).x < -50){
			enemy.timer.stop();
		}
//FuCK WITH THIS SHIT IF YOu WANNA DO THE THING SIS tmumt		
		if(body.get(0).y < 0){
		
			Enemy.enemy.left = true;
			Enemy.enemy.up = false;
			Enemy.enemy.down = true;
		}
		if(body.get(0).x + width > Enemy.enemy.WIDTH){
			
			Enemy.enemy.left = true;
			Enemy.enemy.up = false;
			Enemy.enemy.down = false;
		}
		if(body.get(0).y + height > Enemy.enemy.HEIGHT){
			
			Enemy.enemy.left = true;
			Enemy.enemy.up = true;
			Enemy.enemy.down = false;
		}
		
	
		}
	
	}

	

	
	
	
	
	
	


