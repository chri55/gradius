package main;

public enum Id {
	
	player, enemy, pointsPowerup, supershotPowerup, tile

}
