package dickinaround;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.Timer;

import java.awt.Color;

import java.awt.Graphics;
import java.awt.Rectangle;

public class Enemy implements ActionListener, KeyListener{

	public static Enemy enemy;
	public Renderer renderer;
	public JFrame frame;
	public final int WIDTH = 300, HEIGHT = 300;
	public Body body;
	static Timer timer;
	public boolean up, down, left, right = true;
	public Rectangle food;
	public Random random;
	public int score = 0;
	public int dir = 0;
	public long lastSec = 0;
	int countingAF = 0;
	
	public static void main(String[] args) {
		enemy = new Enemy();

	}
	
	public Enemy(){
		timer = new Timer(20, this);
		
		random = new Random();
		
		renderer = new Renderer();
		frame = new JFrame("dickinaround");
		frame.add(renderer);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(WIDTH, HEIGHT);
		frame.setResizable(false);
		frame.setVisible(true);
		frame.addKeyListener(this);
		
		start();
		
		
	}
	
	private void changeDirection() {
		Random rn = new Random();
		int dir = rn.nextInt(4) + 1;
		//System.out.println(dir);
		
		if(dir == 1 && !down){
			up = true;
			down = false;
			left = false;
			right = false;
		}
		else if(dir == 2 && !up){
			up = false;
			down = true;
			left = false;
			right = false;
		}
		else if(dir == 3 && !right){
			up = false;
			down = false;
			left = true;
			right = false;
		}
		else if(dir == 4 && !left){
			up = false;
			down = false;
			left = false;
			right = true;
		}
		
	}

	public void start(){
		body = new Body(enemy);
		
		timer.start();

	}
	
	public void repaint(Graphics g){
		g.setColor(Color.BLUE.brighter().brighter());
		g.fillRect(0,  0, WIDTH, HEIGHT);
		body.repaint(g);
		g.setColor(Color.WHITE);


	}

	
	

//	public void keyPressed(KeyEvent e) {
//		int id = e.getKeyCode();
//		Random rn = new Random();
//		int dir = rn.nextInt(4) + 1;
//		System.out.println(dir);
//		if(id == KeyEvent.VK_SPACE){
//		if(dir == 1 && !down){
//			up = true;
//			down = false;
//			left = false;
//			right = false;
//		}
//		else if(dir == 2 && !up){
//			up = false;
//			down = true;
//			left = false;
//			right = false;
//		}
//		else if(dir == 3 && !right){
//			up = false;
//			down = false;
//			left = true;
//			right = false;
//		}
//		else if(dir == 4 && !left){
//			up = false;
//			down = false;
//			left = false;
//			right = true;
//		}
//		}
//		
//		
//	}


	public void keyReleased(KeyEvent e) {
	
		
	}


	public void keyTyped(KeyEvent e) {
	
		
	}


	public void actionPerformed(ActionEvent e) {
		update();
		renderer.repaint();
		
	}
	
	public void update(){
		Random rn = new Random();
		int dir = rn.nextInt(4) + 1;
		countingAF++;
		//System.out.println(dir);
		
		if(countingAF % 30 == 0){ //CHANGES DIRECTION
		if(dir == 1 && !down){
			up = true;
			down = false;
			left = false;
			right = false;
		}
		else if(dir == 2 && !up){
			up = false;
			down = true;
			left = false;
			right = false;
		}
		else if(dir == 3 && !right){
			up = false;
			down = false;
			left = true;
			right = false;
		}
		else if(dir == 4 && !left){
			up = false;
			down = false;
			left = false;
			right = true;
		}
		}
		
		
		if(up){
			Body.body.get(0).y -= 3;
		
		}
		else if(down){
			Body.body.get(0).y += 3;
		
		}
		else if(left){
			Body.body.get(0).x -= 3;
			
		}
		else if(right){
			Body.body.get(0).x += 3;
			
		}
		
	
	
		body.update();
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	




}
