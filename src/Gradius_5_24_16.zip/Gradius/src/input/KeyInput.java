package input;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import main.*;
import entity.mob.*;

public class KeyInput implements KeyListener {

	Player player = Gradius.player;
	
	@Override
	public void keyPressed(KeyEvent e) {
		if (!Gradius.running) {
			if (e.getKeyCode() == KeyEvent.VK_1) {
				Gradius.setDifficulty(1);
			} else if (e.getKeyCode() == KeyEvent.VK_2) {
				Gradius.setDifficulty(2);
			} else if (e.getKeyCode() == KeyEvent.VK_3) {
				Gradius.setDifficulty(3);
			} else {
				Gradius.setDifficulty(1);
			}
			Gradius.running = true;
		}

		if (!Gradius.paused) {
			if (e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_W) {
				player.up = true;
			} else if (e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_S) {
				player.down = true;
			} else if (e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_A) {
				player.left = true;

			} else if (e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_D) {
				player.right = true;
			}
		}
		if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {

			if (!Gradius.running) {
				Gradius.paused = false;
			}
			//if (pauseState == 0) {
			//	pauseState = 1;
			//	paused = true;
			//	System.out.println("Paused");
			//} else if (pauseState == 1) {
			//	pauseState = 0;
			//	paused = false;
			//	System.out.println("unpaused");
			//}
		}
	}

	public void keyReleased(KeyEvent e) {
		int key = e.getKeyCode();
		for (Entity en : Gradius.handler.entity) {
			if (en.getId() == Id.player) {
				switch (key) {
				case KeyEvent.VK_UP:
					en.setVelY(0);
					break;
				// case KeyEvent.VK_DOWN:
				// en.setVelY(0);
				// break;
				case KeyEvent.VK_LEFT:
					en.setVelX(0);
					break;
				case KeyEvent.VK_RIGHT:
					en.setVelX(0);
					break;
				}
			}
		}
	}

	public void keyTyped(KeyEvent e) {
	}

}
