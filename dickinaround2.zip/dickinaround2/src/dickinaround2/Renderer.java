package dickinaround2;

import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

public class Renderer extends JPanel {
	private static final long serialVersionUID = 1L;
	
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		Enemy.enemy.repaint((Graphics2D) g);
		
		
		
	}
	
	
}
