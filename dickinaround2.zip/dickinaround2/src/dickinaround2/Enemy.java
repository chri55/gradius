package dickinaround2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.Timer;

import java.awt.Color;

import java.awt.Graphics;
import java.awt.Rectangle;

public class Enemy implements ActionListener, KeyListener{

	public static Enemy enemy;
	public Renderer renderer;
	public JFrame frame;
	public final int WIDTH = 300, HEIGHT = 300;
	public Body body;
	static Timer timer;
	public boolean up, down = false;
	public boolean left = true;
	public Rectangle food;
	public Random random;
	public int score = 0;
	public int dir = 0;
	public long lastSec = 0;
	int countingAF = 0;
	
	public static void main(String[] args) {
		enemy = new Enemy();

	}
	
	public Enemy(){
		timer = new Timer(20, this);
		
		random = new Random();
		
		renderer = new Renderer();
		frame = new JFrame("nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
		frame.add(renderer);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(WIDTH, HEIGHT);
		frame.setResizable(false);
		frame.setVisible(true);
		frame.addKeyListener(this);
		
		start();
		
		
	}
	


	public void start(){
		body = new Body(enemy);
		
		timer.start();

	}
	
	public void repaint(Graphics g){
		g.setColor(Color.BLUE.brighter().brighter());
		g.fillRect(0,  0, WIDTH, HEIGHT);
		body.repaint(g);
		g.setColor(Color.WHITE);


	}

	
	




	public void keyReleased(KeyEvent e) {
	
		
	}


	public void keyTyped(KeyEvent e) {
	
		
	}


	public void actionPerformed(ActionEvent e) {
		update();
		renderer.repaint();
		
	}
	
	public void update(){
		Random rn = new Random();
		int dir = rn.nextInt(3) + 1;
		countingAF++;
		//System.out.println(dir);
		
		if(countingAF % 10 == 0){ //CHANGES DIRECTION
		if(dir == 1 && !down){
			up = true;
			down = false;
			left = false;
			
		}
		else if(dir == 2 && !up){
			up = false;
			down = true;
			left = false;
			
		}
		else if(dir == 3 ){
			up = false;
			down = false;
			left = true;
		
		}
	
		}
		
		
		if(up){
			Body.body.get(0).y -= 3;
		
		}
		else if(down){
			Body.body.get(0).y += 3;
		
		}
		else if(left){
			Body.body.get(0).x -= 3;
			
		}
		
		
	
	
		body.update();
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	




}
