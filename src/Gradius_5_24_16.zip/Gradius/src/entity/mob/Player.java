package entity.mob;

import java.awt.Graphics;

import main.Gradius;
import main.Handler;
import main.Id;
import tile.Tile;
import entity.powerups.*;

public class Player extends Entity {

	public static boolean up = false, down = false, left = false, right = false;
	public int frame;
	public int frameDelay;

	public Player(int x, int y, int width, int height, boolean solid, Id id, Handler handler) {
		super(x, y, width, height, solid, id, handler);
	}

	public void render(Graphics g) {
		if (facing == 1) { // facing right
			g.drawImage(Gradius.player[frame + 4].getBufferedImage(), x, y, width, height, null);
		}
	}

	public void tick() {
		if (up) {
			if (y > 0) {
				y -= 5 * Gradius.difficulty;
			} else
				y = 0;

		}
		//TODO make a getDifficulty();
		if (down) {
			if (y + height < Gradius.HEIGHT) {
				y += 5 * Gradius.difficulty;
			} else
				y = Gradius.HEIGHT - height;

		}
		if (left) {
			if (x > 0) {
				x -= 5 * Gradius.difficulty;
			} else
				x = 0;
		}
		if (right) {
			if (x + width < Gradius.WIDTH) {
				x += 5 * Gradius.difficulty;
			} else
				x = Gradius.WIDTH - width;
		}

	}

}
